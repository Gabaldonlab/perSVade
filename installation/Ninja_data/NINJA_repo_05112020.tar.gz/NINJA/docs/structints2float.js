var structints2float =
[
    [ "first", "structints2float.html#a708929d819022ff899a29cc5288c1ebe", null ],
    [ "key", "structints2float.html#a8e6cb1dc21e9125f7a822d0786e004ed", null ],
    [ "second", "structints2float.html#a7c27a5931f1e35c60a0da8b81658e909", null ]
];