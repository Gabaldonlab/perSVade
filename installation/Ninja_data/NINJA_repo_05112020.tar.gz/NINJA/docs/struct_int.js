var struct_int =
[
    [ "length", "struct_int.html#a2894ba17eb6001ea4990dc72b54b75a8", null ],
    [ "pointer", "struct_int.html#a3f4ea8274904dcbc6a8ec0d26070cb48", null ]
];