var struct_float =
[
    [ "length", "struct_float.html#ae12c69da9c0c3c780c80a725814ffd2c", null ],
    [ "pointer", "struct_float.html#ae5672de8d9f917353a09fba5d2cb2931", null ]
];