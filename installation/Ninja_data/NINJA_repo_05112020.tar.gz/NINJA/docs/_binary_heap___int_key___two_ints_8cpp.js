var _binary_heap___int_key___two_ints_8cpp =
[
    [ "compare3Ints", "_binary_heap___int_key___two_ints_8cpp.html#a0bf8e44289a5d1318b887a3dbe6a3203", null ],
    [ "compareMyType2", "_binary_heap___int_key___two_ints_8cpp.html#abcec8d045085abdbd1f4d4ef2eb6ec8e", null ]
];