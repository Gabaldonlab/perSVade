var class_distance_reader =
[
    [ "DistanceReader", "class_distance_reader.html#a72990b5a7a716c51bc9800babb1ad6ed", null ],
    [ "DistanceReader", "class_distance_reader.html#a47ba3dd618c5fd838ff01a656a5c9cd9", null ],
    [ "~DistanceReader", "class_distance_reader.html#afb8cba60a6bcf7f4814d297be76b9cb5", null ],
    [ "read", "class_distance_reader.html#afecfe4aef179860eacda30ed521e7573", null ],
    [ "readAndWrite", "class_distance_reader.html#a556884960e4de69a39078d2ef642f5a1", null ],
    [ "write", "class_distance_reader.html#ac6c565a94488665715dac977d32353a2", null ],
    [ "distCalc", "class_distance_reader.html#ac922b8b974d75860b98ba760f04ba478", null ],
    [ "fileSize", "class_distance_reader.html#aefbac73f36b1db926e158e1879f4c279", null ],
    [ "K", "class_distance_reader.html#a19898d2a4cad45e3dca47eaad39a0642", null ],
    [ "numPages", "class_distance_reader.html#ac55d0029e686fdfcc5b260877c422e81", null ],
    [ "r", "class_distance_reader.html#a30409ee7871055a305fba2d5b707a015", null ],
    [ "threads", "class_distance_reader.html#af0621ae213eb74f3edbc578434d6b924", null ]
];