var class_candidate_heap =
[
    [ "CandidateHeap", "class_candidate_heap.html#a7ddaa04ab82c9821d4ac63bbc2445f9c", null ],
    [ "CandidateHeap", "class_candidate_heap.html#a9f5e09a4e0157751cd81b69c566c1700", null ],
    [ "~CandidateHeap", "class_candidate_heap.html#abdbcc88328c293641d76c8a26f5e54e9", null ],
    [ "buildNodeList", "class_candidate_heap.html#a3be4ad358ceebf062311c31cdfc7b327", null ],
    [ "calcDeltaValues", "class_candidate_heap.html#a5e855706e9f4ae3344c3d4d40ca25efd", null ],
    [ "clear", "class_candidate_heap.html#ac60355b267aeadb043cf2d1343f0d0a4", null ],
    [ "insert", "class_candidate_heap.html#a41a89d7d4a17b8dbdb26f8d82664000c", null ],
    [ "removeMin", "class_candidate_heap.html#a149d883abbb968518621afe4e8a62753", null ],
    [ "expired", "class_candidate_heap.html#ac8bfa45eb2635e909b29f0ddb66f8598", null ],
    [ "firstActiveNode", "class_candidate_heap.html#ac12a78b561d91a92aa4898afdc76158f", null ],
    [ "k_over_kprime", "class_candidate_heap.html#a1d082054425fa1db4cfa702049716cc0", null ],
    [ "kPrime", "class_candidate_heap.html#a500b18ae1b674bf4ed6bf126c1da6ec8", null ],
    [ "minDeltaSum", "class_candidate_heap.html#a3e0ded6c95d83781ede17dca33c4aa3a", null ],
    [ "nextActiveNode", "class_candidate_heap.html#abca9b432b70973537f56f0f8e0763995", null ],
    [ "origSize", "class_candidate_heap.html#a8dd6ace8881104795a92d98a903cfc0d", null ],
    [ "prevActiveNode", "class_candidate_heap.html#a9e53532b6e958f9598720bae48238d16", null ],
    [ "rDeltas", "class_candidate_heap.html#acd83927176df76bf8459cc2e57d2f13b", null ],
    [ "representedRowCount", "class_candidate_heap.html#a20947ff764a495dd1d0a67f1b04aca95", null ],
    [ "rowCounts", "class_candidate_heap.html#a735a8e00fbc192b817c2431c5eab5ee4", null ],
    [ "rPrimes", "class_candidate_heap.html#a25bf58f5fab83bc5621b9220c813c992", null ],
    [ "tb", "class_candidate_heap.html#aa40962c2d10437b9a4cdccdba45d3b87", null ]
];