var searchData=
[
  ['kimura2_658',['Kimura2',['../class_argument_handler.html#ae67a9e8d392b5fcc6f75c8fb7a875afda543fa5f6ad05da7f2efa6cefee5ba8d9',1,'ArgumentHandler::Kimura2()'],['../class_distance_calculator.html#affde42ac598a1597aba092e781de6609a08d9cb898efb2c44ad9fd7b09d6c7e50',1,'DistanceCalculator::Kimura2()'],['../class_tree_builder_manager.html#a373cf550fdc215fc25daf72e40b56a8dae1e7c68b84de2d982d8fc029b480cc17',1,'TreeBuilderManager::Kimura2()']]]
];
