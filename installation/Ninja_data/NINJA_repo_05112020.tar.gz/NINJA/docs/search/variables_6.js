var searchData=
[
  ['gapinthesequences_544',['gapInTheSequences',['../class_distance_calculator.html#ae6a08d5f607d2fab97983f956dcee6eb',1,'DistanceCalculator']]],
  ['gaps_5fcount_5fmask_545',['GAPS_COUNT_MASK',['../class_distance_calculator.html#a432c5d8e0379f014219ce28eb81945d5',1,'DistanceCalculator']]]
];
