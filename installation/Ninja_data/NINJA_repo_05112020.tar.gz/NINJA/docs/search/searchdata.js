var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvwxz~",
  1: "abcdfhinst",
  2: "e",
  3: "abcdenrst",
  4: "abcdfgilmnprstw~",
  5: "abcdefghijklmnoprstuvwxz",
  6: "h",
  7: "acfio",
  8: "adfjknst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator"
};

