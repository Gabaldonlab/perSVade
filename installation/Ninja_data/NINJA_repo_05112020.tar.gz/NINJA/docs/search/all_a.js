var searchData=
[
  ['k_174',['K',['../class_distance_reader.html#a19898d2a4cad45e3dca47eaad39a0642',1,'DistanceReader::K()'],['../class_distance_reader_ext_mem.html#afc554fcd80fa6fa3ed494590797e9f52',1,'DistanceReaderExtMem::K()'],['../class_tree_builder.html#ab34a44da83ef16f3cada5eacd6e89d0a',1,'TreeBuilder::K()'],['../class_tree_builder_ext_mem.html#ab53d954a69fb53cd2f3d89a41e6b766d',1,'TreeBuilderExtMem::K()']]],
  ['k_5fover_5fkprime_175',['k_over_kprime',['../class_candidate_heap.html#a1d082054425fa1db4cfa702049716cc0',1,'CandidateHeap']]],
  ['key_176',['key',['../class_node.html#ac00da35d2d67f0cdf4f1176d541bd271',1,'Node::key()'],['../structints4float.html#a166477bc6b0a7b5f1e1a588d7ed9debd',1,'ints4float::key()'],['../structints3.html#adbdf1e24ce105183c6041d37a86905f7',1,'ints3::key()'],['../structints2float.html#a8e6cb1dc21e9125f7a822d0786e004ed',1,'ints2float::key()']]],
  ['kimura2_177',['Kimura2',['../class_argument_handler.html#ae67a9e8d392b5fcc6f75c8fb7a875afda543fa5f6ad05da7f2efa6cefee5ba8d9',1,'ArgumentHandler::Kimura2()'],['../class_distance_calculator.html#affde42ac598a1597aba092e781de6609a08d9cb898efb2c44ad9fd7b09d6c7e50',1,'DistanceCalculator::Kimura2()'],['../class_tree_builder_manager.html#a373cf550fdc215fc25daf72e40b56a8dae1e7c68b84de2d982d8fc029b480cc17',1,'TreeBuilderManager::Kimura2()']]],
  ['kprime_178',['kPrime',['../class_candidate_heap.html#a500b18ae1b674bf4ed6bf126c1da6ec8',1,'CandidateHeap']]]
];
