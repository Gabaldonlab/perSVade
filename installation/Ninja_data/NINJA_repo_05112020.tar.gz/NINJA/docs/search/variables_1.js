var searchData=
[
  ['b_485',['B',['../class_array_heap_ext_mem.html#ab265c5ed6832460974f81d20d468d8b3',1,'ArrayHeapExtMem']]],
  ['bigbuffb_486',['bigBuffB',['../class_array_heap_ext_mem.html#a6a7f40696470a4a00aa81be3cddfd0b6',1,'ArrayHeapExtMem']]],
  ['bigbuffi_487',['bigBuffI',['../class_array_heap_ext_mem.html#a11d7d97518e75793e6419b47860ff400',1,'ArrayHeapExtMem']]],
  ['blocksize_488',['blockSize',['../class_array_heap_ext_mem.html#a27b976bfb35d0fe05d359e01f7b5c0a1',1,'ArrayHeapExtMem']]],
  ['buffb_489',['buffB',['../class_array_heap_ext_mem.html#aa0d9dd841ba0f6e56957daa451ae5dbc',1,'ArrayHeapExtMem']]],
  ['buffi_490',['buffI',['../class_array_heap_ext_mem.html#af6e41001eca36c3177f1c942314b45a2',1,'ArrayHeapExtMem']]]
];
