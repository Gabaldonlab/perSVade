var searchData=
[
  ['origsize_591',['origSize',['../class_candidate_heap.html#a8dd6ace8881104795a92d98a903cfc0d',1,'CandidateHeap']]],
  ['outfile_592',['outFile',['../class_tree_builder_manager.html#a0efd9a961ff0dd21dc150202ad0dab65',1,'TreeBuilderManager']]],
  ['outtype_593',['outType',['../class_tree_builder_manager.html#abdf50c04e7fbf7355186615c94738940',1,'TreeBuilderManager']]]
];
