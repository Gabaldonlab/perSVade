var searchData=
[
  ['filetype_647',['fileType',['../class_sequence_file_reader.html#a38d7a5bd2e01b009daa2fa7f0909ed57',1,'SequenceFileReader']]]
];
