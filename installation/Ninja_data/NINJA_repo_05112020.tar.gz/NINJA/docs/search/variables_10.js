var searchData=
[
  ['r_597',['r',['../class_distance_reader.html#a30409ee7871055a305fba2d5b707a015',1,'DistanceReader::r()'],['../class_tree_builder.html#a2a7cf93c4f83694655b42b66841ec022',1,'TreeBuilder::R()'],['../class_tree_builder_ext_mem.html#a144639ff1015c261a2aaf16803db8c9e',1,'TreeBuilderExtMem::R()']]],
  ['rdeltas_598',['rDeltas',['../class_candidate_heap.html#acd83927176df76bf8459cc2e57d2f13b',1,'CandidateHeap']]],
  ['rebuildstepratio_599',['rebuildStepRatio',['../class_tree_builder.html#aa4858f795129eb29decc59def89f9863',1,'TreeBuilder']]],
  ['rebuildsteps_600',['rebuildSteps',['../class_tree_builder.html#a5ad2e53bba32c295b58874f8085d1b79',1,'TreeBuilder']]],
  ['rebuildstepsconstant_601',['rebuildStepsConstant',['../class_tree_builder.html#a18f0e3b92f71dcba08d8146115d85e03',1,'TreeBuilder']]],
  ['redirect_602',['redirect',['../class_tree_builder.html#a920fc80b7d5e19e0caabeb21827eae40',1,'TreeBuilder::redirect()'],['../class_tree_builder_ext_mem.html#a626f360d5e7bd8226f7796c48e0cee5d',1,'TreeBuilderExtMem::redirect()']]],
  ['remaining_603',['remaining',['../class_slot_pair.html#ac76d354c310b27e26935b46a4a20f446',1,'SlotPair']]],
  ['representedrowcount_604',['representedRowCount',['../class_candidate_heap.html#a20947ff764a495dd1d0a67f1b04aca95',1,'CandidateHeap']]],
  ['returncandstoheaps_605',['returnCandsToHeaps',['../class_tree_builder_ext_mem.html#a35de8f4813b88b208a34bbe6e37df09d',1,'TreeBuilderExtMem']]],
  ['rightchild_606',['rightChild',['../class_tree_node.html#adff65b014ee0791bf95b9715f8ebabf9',1,'TreeNode']]],
  ['rowcounts_607',['rowCounts',['../class_candidate_heap.html#a735a8e00fbc192b817c2431c5eab5ee4',1,'CandidateHeap']]],
  ['rowlength_608',['rowLength',['../class_tree_builder_ext_mem.html#a5d132013eba6278067226c65ff4befdf',1,'TreeBuilderExtMem']]],
  ['rprimes_609',['rPrimes',['../class_candidate_heap.html#a25bf58f5fab83bc5621b9220c813c992',1,'CandidateHeap']]],
  ['rsize_610',['RSize',['../class_tree_builder_ext_mem.html#a480540a8c4d691e82da94e1c1b9799a8',1,'TreeBuilderExtMem']]]
];
