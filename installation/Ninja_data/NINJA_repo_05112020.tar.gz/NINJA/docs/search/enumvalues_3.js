var searchData=
[
  ['jukescantor_657',['JukesCantor',['../class_argument_handler.html#ae67a9e8d392b5fcc6f75c8fb7a875afda73811e507c334774db6b1ab687639b5f',1,'ArgumentHandler::JukesCantor()'],['../class_distance_calculator.html#affde42ac598a1597aba092e781de6609aeb17fea69ad9aef888f2419a2814abf9',1,'DistanceCalculator::JukesCantor()'],['../class_tree_builder_manager.html#a373cf550fdc215fc25daf72e40b56a8da78e91f6ce40102b0d61e8b9d51750638',1,'TreeBuilderManager::JukesCantor()']]]
];
