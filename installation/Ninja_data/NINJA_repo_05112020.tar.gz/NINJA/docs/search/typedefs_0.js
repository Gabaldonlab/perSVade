var searchData=
[
  ['heapreturn_644',['HeapReturn',['../_array_heap_ext_mem_8hpp.html#a70f21bb9c2daeb690c71d6f05b24d399',1,'ArrayHeapExtMem.hpp']]]
];
