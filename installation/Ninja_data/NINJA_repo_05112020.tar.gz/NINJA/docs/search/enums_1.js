var searchData=
[
  ['correctiontype_646',['CorrectionType',['../class_argument_handler.html#ae67a9e8d392b5fcc6f75c8fb7a875afd',1,'ArgumentHandler::CorrectionType()'],['../class_distance_calculator.html#affde42ac598a1597aba092e781de6609',1,'DistanceCalculator::CorrectionType()'],['../class_tree_builder_manager.html#a373cf550fdc215fc25daf72e40b56a8d',1,'TreeBuilderManager::CorrectionType()']]]
];
