var _array_heap_ext_mem_8cpp =
[
    [ "compareMyTypeExt", "_array_heap_ext_mem_8cpp.html#a3fb92b0e9c304c2d50afb008bb960562", null ]
];