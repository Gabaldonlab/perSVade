var _exception_handler_8hpp =
[
    [ "critical", "_exception_handler_8hpp.html#afc6a5220fa5ef6fe9ecad07c03cdfb3d", null ],
    [ "criticalErrno", "_exception_handler_8hpp.html#af03aae6516e5aada15e7472b53a3e512", null ]
];