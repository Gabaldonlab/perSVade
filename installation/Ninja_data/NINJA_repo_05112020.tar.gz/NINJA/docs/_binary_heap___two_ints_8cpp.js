var _binary_heap___two_ints_8cpp =
[
    [ "compare2IntsFloat", "_binary_heap___two_ints_8cpp.html#a1cdc4dd6f060de22827181899d786e2d", null ],
    [ "compareMyType3", "_binary_heap___two_ints_8cpp.html#af25231a37e3a3a514703da7dd6c43afb", null ]
];