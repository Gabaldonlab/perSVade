var hierarchy =
[
    [ "ArgumentHandler", "class_argument_handler.html", null ],
    [ "ArrayHeapExtMem", "class_array_heap_ext_mem.html", [
      [ "CandidateHeap", "class_candidate_heap.html", null ]
    ] ],
    [ "BinaryHeap", "class_binary_heap.html", null ],
    [ "BinaryHeap_FourInts", "class_binary_heap___four_ints.html", null ],
    [ "BinaryHeap_IntKey_TwoInts", "class_binary_heap___int_key___two_ints.html", null ],
    [ "BinaryHeap_TwoInts", "class_binary_heap___two_ints.html", null ],
    [ "DistanceCalculator", "class_distance_calculator.html", null ],
    [ "DistanceReader", "class_distance_reader.html", null ],
    [ "DistanceReaderExtMem", "class_distance_reader_ext_mem.html", null ],
    [ "Float", "struct_float.html", null ],
    [ "HeapReturn", "struct_heap_return.html", null ],
    [ "Int", "struct_int.html", null ],
    [ "ints2float", "structints2float.html", null ],
    [ "ints3", "structints3.html", null ],
    [ "ints4float", "structints4float.html", null ],
    [ "Node", "class_node.html", null ],
    [ "SequenceFileReader", "class_sequence_file_reader.html", null ],
    [ "SlotPair", "class_slot_pair.html", null ],
    [ "Stack", "class_stack.html", null ],
    [ "TreeBuilder", "class_tree_builder.html", [
      [ "TreeBuilderBinHeap", "class_tree_builder_bin_heap.html", null ]
    ] ],
    [ "TreeBuilderExtMem", "class_tree_builder_ext_mem.html", null ],
    [ "TreeBuilderManager", "class_tree_builder_manager.html", null ],
    [ "TreeNode", "class_tree_node.html", null ]
];