var namespaces_dup =
[
    [ "Exception", "namespace_exception.html", null ]
];