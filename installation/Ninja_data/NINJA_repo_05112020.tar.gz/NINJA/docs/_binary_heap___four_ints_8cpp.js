var _binary_heap___four_ints_8cpp =
[
    [ "compare4Ints", "_binary_heap___four_ints_8cpp.html#add9b3fa7d2c13285a9380cdde25ad755", null ],
    [ "compareMyType4", "_binary_heap___four_ints_8cpp.html#ae286ed888e0aedac2e4b1ce5e103683d", null ]
];