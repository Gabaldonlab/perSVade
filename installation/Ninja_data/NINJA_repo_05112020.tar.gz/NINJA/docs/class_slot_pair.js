var class_slot_pair =
[
    [ "SlotPair", "class_slot_pair.html#ac09540de71ab2af1b8ec8265f1453760", null ],
    [ "compareTo", "class_slot_pair.html#a1304d88a845660a897d8ad3abc9acb17", null ],
    [ "remaining", "class_slot_pair.html#ac76d354c310b27e26935b46a4a20f446", null ],
    [ "slot", "class_slot_pair.html#a1ae791f11a43cb33f46cadaee24d8ecb", null ]
];