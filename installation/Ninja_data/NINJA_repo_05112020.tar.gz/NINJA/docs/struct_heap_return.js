var struct_heap_return =
[
    [ "h", "struct_heap_return.html#ad3af739a005b61242cf1b5e02a2cf740", null ],
    [ "which", "struct_heap_return.html#a92d5327a236a872dd1d0598fac7685ba", null ]
];