var _binary_heap_8cpp =
[
    [ "comp", "_binary_heap_8cpp.html#a45273d1a6fdba12d3434f75fca464dd5", null ],
    [ "compareMyType", "_binary_heap_8cpp.html#aaf20367a1addb550af6ea07720e55859", null ]
];