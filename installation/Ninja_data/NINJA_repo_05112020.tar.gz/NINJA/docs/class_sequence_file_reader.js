var class_sequence_file_reader =
[
    [ "AlphabetType", "class_sequence_file_reader.html#a8cc42e15f26ed4a680ac4b968f0922a7", [
      [ "dna", "class_sequence_file_reader.html#a8cc42e15f26ed4a680ac4b968f0922a7aeafabf791da5b60629a8c2eea71c9ee1", null ],
      [ "amino", "class_sequence_file_reader.html#a8cc42e15f26ed4a680ac4b968f0922a7acae42440ed46d49841a42325c14aaf41", null ],
      [ "null", "class_sequence_file_reader.html#a8cc42e15f26ed4a680ac4b968f0922a7a9388aafb7eda9f884eed4c4dc315cc24", null ]
    ] ],
    [ "fileType", "class_sequence_file_reader.html#a38d7a5bd2e01b009daa2fa7f0909ed57", [
      [ "fasta", "class_sequence_file_reader.html#a38d7a5bd2e01b009daa2fa7f0909ed57a04f278c472cd9257e9f801c8094076a2", null ],
      [ "stockholm", "class_sequence_file_reader.html#a38d7a5bd2e01b009daa2fa7f0909ed57a71d055fafc2c7e7bda14e4aa68119a9c", null ]
    ] ],
    [ "SequenceFileReader", "class_sequence_file_reader.html#afefc977e0ab5e10c56afbf0f2fa2ada8", null ],
    [ "~SequenceFileReader", "class_sequence_file_reader.html#a68f93cafb0fff8017a6ddfdac763b2ec", null ],
    [ "getAlphType", "class_sequence_file_reader.html#a19cd3893e28924779bfcb74a1cece03b", null ],
    [ "getNames", "class_sequence_file_reader.html#a90a7fe721e3311573775ab8f7c946ec9", null ],
    [ "getSeqs", "class_sequence_file_reader.html#ac6ddf2c86a6e8c25f21d9e1381cb08ce", null ],
    [ "alphType", "class_sequence_file_reader.html#a9318592fe459d2b67d3fb191b1f75057", null ],
    [ "filetype", "class_sequence_file_reader.html#a5599fbffb34bd065bfb846947c6e9c41", null ],
    [ "names", "class_sequence_file_reader.html#ac5ad200019599845c0f1bc226ce0161b", null ],
    [ "numSeqs", "class_sequence_file_reader.html#aac56176cc7a6ed92728a106576ec3382", null ],
    [ "seqs", "class_sequence_file_reader.html#a4ed189180afd320f49605425fad1a0d9", null ]
];