var class_node =
[
    [ "Node", "class_node.html#a439595ca0e98fe92ee87a54b509a7810", null ],
    [ "Node", "class_node.html#ad7a34779cad45d997bfd6d3d8043c75f", null ],
    [ "i", "class_node.html#ac92c571228f56330b3e37ca1d43feb93", null ],
    [ "j", "class_node.html#a747e7d35178b7a2c4020b9ca4d26ea89", null ],
    [ "key", "class_node.html#ac00da35d2d67f0cdf4f1176d541bd271", null ]
];