var structints3 =
[
    [ "first", "structints3.html#a44509ea329d02b47adfdc3c9dfa06fe6", null ],
    [ "key", "structints3.html#adbdf1e24ce105183c6041d37a86905f7", null ],
    [ "second", "structints3.html#a4120d2414dcc65bd2d441de85875720d", null ]
];