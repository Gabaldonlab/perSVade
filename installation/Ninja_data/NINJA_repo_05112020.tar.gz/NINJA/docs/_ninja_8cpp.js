var _ninja_8cpp =
[
    [ "main", "_ninja_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];